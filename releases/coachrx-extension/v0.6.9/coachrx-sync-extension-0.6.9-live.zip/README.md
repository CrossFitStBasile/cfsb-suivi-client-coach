# CFSB CoachRx Sync Extension

Extension Chrome MV3 pour synchroniser le roster API CoachRx verifie vers le Dashboard Coach CFSB.

Version actuelle: `0.6.9`. L'extension a une icone CFSB/Rx distincte pour eviter de la confondre avec les autres extensions Chrome.
Elle remet automatiquement l'URL Apps Script officielle au prochain chargement de
l'extension, sans modifier le secret de synchronisation deja enregistre dans
Chrome. Cela empeche une ancienne route de synchronisation de reintroduire une
source non verifiee.
Cette version refuse la page generique `/clients`: le coach doit etre verifiable dans
l'URL `/team/{coachId}/clients`, et la source API doit correspondre au
coach selectionne. Elle refuse aussi une synchronisation si CoachRx ne fournit pas
une identite client stable pour chaque fiche importable. Cela protege les
portefeuilles contre les fusions ou transferts fondes seulement sur un nom.
La lecture API se fait dans la session CoachRx deja ouverte par le coach. CoachRx
protege maintenant cette route avec le jeton de session conserve sous `token` dans
le `localStorage`. La version 0.6.9 utilise ce jeton uniquement dans la page pour
ajouter l'en-tete `Authorization` attendu par CoachRx. Le jeton n'est jamais
retourne au popup, journalise, sauvegarde par l'extension ou transmis a Apps Script.
Seules les donnees client structurees sont retournees par la page.

Avant toute synchronisation, l'extension separe les fiches actives et archivees.
Elle compare les clients actifs extraits a l'onglet `Active` et a la carte
`Total Clients`, puis compare les fiches archivees a l'onglet `Archived`. Seuls les
clients actifs sont transmis a Apps Script; les archives servent uniquement au
controle d'integrite. Si un compteur est introuvable ou ne concorde pas, la
synchronisation est bloquee. Les pourcentages de compliance ne sont jamais utilises
comme compteurs de clients. L'etat CoachRx doit etre explicitement `active` ou
`archived`; toute valeur vide ou inconnue bloque aussi la synchronisation.
Quand CoachRx les expose dans sa reponse API, l'extension transmet aussi le telephone et le courriel comme preuves privees de rapprochement. Ces coordonnees ne servent jamais a attribuer un client par nom seul.

## Installation locale

1. Ouvrir Chrome.
2. Aller a `chrome://extensions`.
3. Activer `Mode developpeur`.
4. Cliquer `Charger l'extension non empaquetee`.
5. Choisir le dossier extrait qui contient directement le fichier `manifest.json`.

## Utilisation

1. Ouvrir `https://dashboard.coachrx.app/` et se connecter.
2. Choisir le coach dans l'extension et utiliser `Ouvrir CoachRx` pour aller dans
   sa vue `/team/{coachId}/clients`.
3. Cliquer sur l'extension `CFSB CoachRx Sync`.
4. Verifier que l'URL Apps Script est deja remplie et marquee geree automatiquement. Ne pas la modifier.
5. Entrer le `Secret de sync CoachRx`.
6. Cliquer `Charger les coachs`.
7. Choisir le coach dans la liste deroulante.
8. Cliquer `Enregistrer`.
9. Cliquer `Tester CoachRx` et verifier que `Clients actifs valides` correspond a
   l'onglet `Active`, que `Clients archives ignores` correspond a l'onglet
   `Archived`, et que `Identites stables` couvre tous les clients actifs lus.
   Cliquer ensuite sur `Synchroniser CoachRx`.
10. Pour explorer une page CoachRx plus en profondeur, ouvrir la page voulue puis cliquer `Scan avance CoachRx`.

Le secret doit aussi exister dans les proprietes du Apps Script lie au dashboard:

- propriete: `COACHRX_SYNC_SECRET`
- valeur: le meme secret que celui entre dans l'extension

La liste deroulante vient de l'onglet cache `CFG_Coachs`. Pour ajouter un coach, ajoute une ligne dans cet onglet avec son nom et son `CoachRx ID`.

## Donnees synchronisees

Cette version tente d'abord de lire l'API utilisee par la page CoachRx connectee:

- clients actifs du coach (les fiches archivees sont controlees mais non transmises);
- dates `Exercise due` et `Lifestyle due` si disponibles;
- compliance exercice/lifestyle si disponible;
- streak, workouts completed, touchpoints, tags et alerte si disponibles.

Si l'API ne repond pas, la synchronisation est refusee. Il n'existe pas de lecture de secours de la page visible, car elle ne prouve pas de maniere fiable le portefeuille du coach.

## Destination Google Sheet

Le Web App Apps Script met a jour l'onglet technique cache:

- `SRC_CoachRx_Browser_All`: source globale multi-coachs, avec `Coach ID` et `Coach`.
- `SRC_CoachRx_Browser`: copie de compatibilite du dernier coach synchronise, utilisee par le pilote Marc-Andre.
- `SRC_CoachRx_Advanced_Scans`: inventaire cache des pages CoachRx scannees avec le bouton `Scan avance CoachRx`.
- `CFG_Coachs`: configuration des coachs, cachee dans le dashboard.

Pour le pilote Marc-Andre, le dashboard utilise ensuite cette source pour reconstruire automatiquement:

- `To_Do_Coach`
- `Dashboard_Marc_Andre`
- `Formulaires_Fin_Programme`
- `Clients_A_Valider`

## Notes

Le Google Sheet ne peut pas scanner CoachRx lui-meme. L'extension le fait depuis le navigateur connecte de l'utilisateur, puis transmet seulement le resultat structure au Apps Script.

Une URL sans `team/<id>/clients` est refusee. Utilise toujours le bouton `Ouvrir CoachRx`
de l'extension avant de lancer la synchronisation.
