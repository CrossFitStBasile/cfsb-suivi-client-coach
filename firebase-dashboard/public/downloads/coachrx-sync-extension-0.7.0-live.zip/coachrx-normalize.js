(function attachCoachRxNormalizer(scope) {
  "use strict";

  const CLIENT_KEYS = Object.freeze([
    "importedAt",
    "coachId",
    "sourcePath",
    "id",
    "identityKind",
    "identitySource",
    "phone",
    "phoneSource",
    "email",
    "emailSource",
    "name",
    "state",
    "workoutDue",
    "exerciseColor",
    "exerciseStatus",
    "workoutDueDays",
    "workoutDueLocked",
    "compliance7",
    "compliance30",
    "compliance90",
    "lifestyleDue",
    "lifestyleColor",
    "lifestyleStatus",
    "lifestyleCompliance7",
    "lifestyleCompliance30",
    "lifestyleCompliance90",
    "completedWorkouts",
    "streak",
    "lastConsultation",
    "touchpoints",
    "tags",
    "alert",
    "programSignal",
    "complianceSignal",
    "lifestyleSignal"
  ]);

  const IDENTITY_REPORT_KEYS = Object.freeze([
    "totalCount",
    "identifiedCount",
    "missingCount",
    "bySource",
    "byKind",
    "withPhoneCount",
    "withEmailCount",
    "phoneBySource",
    "emailBySource"
  ]);

  function normalizeRoster(rawClients, coachId, sourcePath, identityApi) {
    if (!Array.isArray(rawClients)) {
      throw new Error("Roster CoachRx non valide; synchronisation bloquee.");
    }
    if (!identityApi || typeof identityApi.resolve !== "function"
      || typeof identityApi.resolveContact !== "function"
      || typeof identityApi.summarize !== "function") {
      throw new Error("Module d'identite CoachRx indisponible. Recharge l'extension puis reessaie.");
    }

    const importableRawClients = rawClients.filter((client) => pickClientName(client));
    const importedAt = new Date().toISOString();
    const clients = importableRawClients.map((client) => normalizeClient(
      client,
      coachId,
      sourcePath,
      identityApi,
      importedAt
    ));
    const identityReport = identityApi.summarize(importableRawClients);

    return {
      clients,
      identityReport: pickExactKeys(identityReport, IDENTITY_REPORT_KEYS)
    };
  }

  function normalizeClient(client, coachId, sourcePath, identityApi, importedAt) {
    const identity = identityApi.resolve(client);
    const contact = identityApi.resolveContact(client);
    const workoutDue = firstValue(client.workout_due_date, client.exercise_due_date, client.next_workout_due_date);
    const lifestyleDue = firstValue(client.lifestyle_due_date, client.lifestyle_rx_due_date, client.next_lifestyle_due_date);
    const dueDays = daysFromToday(workoutDue);
    const exerciseColor = firstValue(client.exercise_color, client.workout_color, client.exercise_due_color, client.workout_due_color, client.exercise_status_color);
    const exerciseStatus = firstValue(client.exercise_status, client.workout_status, client.exercise_due_status, client.workout_due_status);
    const lifestyleColor = firstValue(client.lifestyle_color, client.lifestyle_due_color, client.lifestyle_status_color);
    const lifestyleStatus = firstValue(client.lifestyle_status, client.lifestyle_due_status);
    const compliance30 = numberOrBlank(client.compliance_30_days);
    const lifestyleCompliance30 = numberOrBlank(client.lifestyle_compliance_30_days);
    const programSignal = buildProgramSignal(dueDays);

    const normalized = {
      importedAt,
      coachId: stringValue(coachId),
      sourcePath: stringValue(sourcePath),
      id: identity.value,
      identityKind: identity.kind,
      identitySource: identity.source,
      phone: contact.phone,
      phoneSource: contact.phoneSource,
      email: contact.email,
      emailSource: contact.emailSource,
      name: pickClientName(client),
      state: stringValue(client.state || client.status || "active"),
      workoutDue,
      exerciseColor,
      exerciseStatus,
      workoutDueDays: dueDays,
      workoutDueLocked: firstValue(client.workout_due_date_locked, client.exercise_due_date_locked),
      compliance7: numberOrBlank(client.compliance_7_days),
      compliance30,
      compliance90: numberOrBlank(client.compliance_90_days),
      lifestyleDue,
      lifestyleColor,
      lifestyleStatus,
      lifestyleCompliance7: numberOrBlank(client.lifestyle_compliance_7_days),
      lifestyleCompliance30,
      lifestyleCompliance90: numberOrBlank(client.lifestyle_compliance_90_days),
      completedWorkouts: firstValue(client.completed_workouts, client.workouts_completed),
      streak: firstValue(client.current_streak_count, client.highest_streak),
      lastConsultation: firstValue(client.last_consultation),
      touchpoints: firstValue(client.touch_points_count),
      tags: normalizeTags(firstValue(client.tags, client.Tags)),
      alert: alertText(client.client_alert),
      programSignal,
      complianceSignal: compliance30 !== "" && compliance30 < 50 ? "Compliance exercice basse" : "",
      lifestyleSignal: lifestyleCompliance30 !== "" && lifestyleCompliance30 < 50 ? "Compliance lifestyle basse" : ""
    };

    return pickExactKeys(normalized, CLIENT_KEYS);
  }

  function pickExactKeys(value, keys) {
    const result = {};
    for (const key of keys) result[key] = value?.[key];
    return result;
  }

  function pickClientName(client) {
    const candidates = [
      client?.name,
      client?.full_name,
      client?.client_name,
      client?.user && client.user.name,
      client?.client && client.client.name,
      client?.athlete && client.athlete.name,
      [client?.first_name, client?.last_name].filter(Boolean).join(" "),
      [client?.user && client.user.first_name, client?.user && client.user.last_name].filter(Boolean).join(" "),
      [client?.client && client.client.first_name, client?.client && client.client.last_name].filter(Boolean).join(" ")
    ];
    const rejected = new Set(["not set", "invite pending", "active", "archived", "dd"]);
    return candidates
      .map((value) => stringValue(value))
      .find((value) => value && !rejected.has(value.toLowerCase())) || "";
  }

  function buildProgramSignal(dueDays) {
    if (dueDays === "") return "";
    if (dueDays < 0) return "Programme en retard";
    if (dueDays <= 14) return "Programme a preparer";
    return "";
  }

  function daysFromToday(value) {
    if (!value) return "";
    const date = parseDateOnly(value) || parseCoachRxDisplayDate(value);
    if (!date) return "";
    const now = new Date();
    const today = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
    const target = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    return Math.round((target - today) / 86400000);
  }

  function parseDateOnly(value) {
    const text = stringValue(value);
    const match = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!match) return null;
    return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  }

  function parseCoachRxDisplayDate(value) {
    const text = stringValue(value).toLowerCase();
    const today = new Date();
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const monthNames = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
    if (/^last\s+/.test(text)) {
      const day = dayNames.findIndex((name) => text.includes(name));
      if (day === -1) return null;
      const diff = (today.getDay() - day + 7) % 7 || 7;
      return new Date(today.getFullYear(), today.getMonth(), today.getDate() - diff);
    }
    const weekday = dayNames.indexOf(text);
    if (weekday !== -1) {
      const diff = (weekday - today.getDay() + 7) % 7;
      return new Date(today.getFullYear(), today.getMonth(), today.getDate() + diff);
    }
    const absolute = text.match(/^(sun|mon|tue|wed|thu|fri|sat)\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+(\d{1,2})/);
    if (absolute) {
      const month = monthNames[absolute[2]];
      const day = Number(absolute[3]);
      const year = today.getFullYear() + (month < today.getMonth() - 6 ? 1 : 0);
      return new Date(year, month, day);
    }
    return null;
  }

  function firstValue(...values) {
    return values.find((value) => value !== undefined && value !== null && stringValue(value) !== "") ?? "";
  }

  function numberOrBlank(value) {
    if (value === undefined || value === null || value === "") return "";
    const number = Number(String(value).replace("%", "").trim());
    return Number.isFinite(number) ? number : "";
  }

  function normalizeTags(value) {
    if (Array.isArray(value)) return value.map((tag) => stringValue(tag?.name || tag)).filter(Boolean).join(", ");
    return stringValue(value);
  }

  function alertText(value) {
    if (!value) return "";
    if (typeof value === "string") return value;
    return stringValue(value.message || value.text || value.title);
  }

  function stringValue(value) {
    return value === undefined || value === null ? "" : String(value).trim();
  }

  scope.CFSBCoachRxNormalize = Object.freeze({
    CLIENT_KEYS,
    IDENTITY_REPORT_KEYS,
    normalizeRoster
  });
})(globalThis);
