export const INTEGRATED_PROTOCOL = "integrated-v1";
export const EXTENSION_VERSION = "0.7.0";

const CONFIG_OPERATION = "get_coaches";
const VALIDATE_OPERATION = "validate_roster";
const IMPORT_OPERATION = "import_roster";
const IDENTIFIER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const RAW_CLIENT_ID_PATTERN = /^[A-Za-z0-9_-]{1,128}$/;
const DIGEST_PATTERN = /^[a-f0-9]{64}$/;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export const CLIENT_DATA_KEYS = Object.freeze([
  "identityKind",
  "identitySource",
  "phone",
  "phoneSource",
  "email",
  "emailSource",
  "name",
  "state",
  "workoutDue",
  "exerciseColor",
  "exerciseStatus",
  "workoutDueDays",
  "workoutDueLocked",
  "compliance7",
  "compliance30",
  "compliance90",
  "lifestyleDue",
  "lifestyleColor",
  "lifestyleStatus",
  "lifestyleCompliance7",
  "lifestyleCompliance30",
  "lifestyleCompliance90",
  "completedWorkouts",
  "streak",
  "lastConsultation",
  "touchpoints",
  "tags",
  "alert",
  "programSignal",
  "complianceSignal",
  "lifestyleSignal"
]);

export function createConfigRequest() {
  return Object.freeze({
    protocol: INTEGRATED_PROTOCOL,
    operation: CONFIG_OPERATION,
    extensionVersion: EXTENSION_VERSION
  });
}

export function createImportRunId(randomUUID = globalThis.crypto?.randomUUID?.bind(globalThis.crypto)) {
  if (typeof randomUUID !== "function") {
    throw new Error("Generation securisee de l'identifiant d'import indisponible.");
  }
  const value = String(randomUUID()).trim().toLowerCase();
  if (!UUID_PATTERN.test(value)) {
    throw new Error("L'identifiant d'import genere n'est pas un UUID valide.");
  }
  return value;
}

export async function createImportRequest(input, subtle = globalThis.crypto?.subtle) {
  const workspaceId = strictIdentifier(input?.workspaceId, "workspaceId");
  const sourceCoachId = strictIdentifier(input?.sourceCoachId, "sourceCoachId");
  const importRunId = strictImportRunId(input?.importRunId);
  const extractedAt = strictIsoInstant(input?.extractedAt);
  const clients = qualifyClients(input?.clients, workspaceId, sourceCoachId);
  const expectedClientCount = strictCount(input?.expectedClientCount, "expectedClientCount");
  const archivedClientCount = strictCount(input?.archivedClientCount, "archivedClientCount");
  const apiClientCount = strictCount(input?.apiClientCount, "apiClientCount");
  const countSource = strictText(input?.countSource, "countSource", 80, false);

  if (clients.length !== expectedClientCount) {
    throw new Error("Le nombre de clients qualifies ne correspond pas au compteur CoachRx actif.");
  }
  if (apiClientCount !== expectedClientCount + archivedClientCount) {
    throw new Error("Le total API ne correspond pas aux compteurs actifs et archives.");
  }

  const snapshot = {
    workspaceId,
    sourceCoachId,
    importRunId,
    extractedAt,
    expectedClientCount,
    archivedClientCount,
    apiClientCount,
    countSource,
    clients
  };
  const digest = await sha256Hex(canonicalJson(snapshot), subtle);
  return Object.freeze({
    protocol: INTEGRATED_PROTOCOL,
    operation: IMPORT_OPERATION,
    extensionVersion: EXTENSION_VERSION,
    snapshot: deepFreeze(snapshot),
    digest
  });
}

export async function createValidateRequest(input, subtle = globalThis.crypto?.subtle) {
  const request = await createImportRequest(input, subtle);
  return Object.freeze({
    ...request,
    operation: VALIDATE_OPERATION,
    dryRun: true
  });
}

export async function runSameRequestReplay(request, send) {
  assertExactKeys(request, ["protocol", "operation", "extensionVersion", "snapshot", "digest"], "requete de replay");
  if (request.protocol !== INTEGRATED_PROTOCOL || request.operation !== IMPORT_OPERATION) {
    throw new Error("Le replay controle exige une requete import_roster integrated-v1.");
  }
  if (typeof send !== "function") {
    throw new Error("Le transport du replay controle n'est pas disponible.");
  }

  const first = validateImportAck(await send(request, 1), request);
  const replay = validateImportAck(await send(request, 2), request);
  if (canonicalJson(first) !== canonicalJson(replay)) {
    throw new Error("Le replay n'a pas retourne exactement le meme ACK d'import.");
  }
  return Object.freeze({
    first,
    replay,
    sameRequestReused: true
  });
}

export function validateConfigAck(response) {
  assertExactKeys(response, ["ok", "protocol", "ack"], "reponse de configuration");
  if (response.ok !== true || response.protocol !== INTEGRATED_PROTOCOL) {
    throw new Error("Le backend n'a pas confirme integrated-v1.");
  }
  const ack = response.ack;
  assertExactKeys(ack, ["operation", "status", "workspaceId", "coaches"], "ACK de configuration");
  if (ack.operation !== CONFIG_OPERATION || ack.status !== "accepted") {
    throw new Error("L'ACK de configuration n'est pas accepte.");
  }
  const workspaceId = strictIdentifier(ack.workspaceId, "workspaceId");
  if (!Array.isArray(ack.coaches) || ack.coaches.length === 0 || ack.coaches.length > 100) {
    throw new Error("La liste de coachs integrated-v1 n'est pas valide.");
  }
  const seen = new Set();
  const coaches = ack.coaches.map((coach) => {
    assertExactKeys(coach, ["sourceCoachId", "label"], "fiche coach");
    const sourceCoachId = strictIdentifier(coach.sourceCoachId, "sourceCoachId");
    const label = strictText(coach.label, "label", 120, false);
    if (seen.has(sourceCoachId)) throw new Error("La liste contient un sourceCoachId en double.");
    seen.add(sourceCoachId);
    return Object.freeze({ sourceCoachId, label });
  });
  return Object.freeze({ workspaceId, coaches: Object.freeze(coaches) });
}

export function validateImportAck(response, request) {
  assertExactKeys(response, ["ok", "protocol", "ack"], "reponse d'import");
  if (response.ok !== true || response.protocol !== INTEGRATED_PROTOCOL) {
    throw new Error("Le backend n'a pas confirme integrated-v1.");
  }
  assertExactKeys(request, ["protocol", "operation", "extensionVersion", "snapshot", "digest"], "requete d'import attendue");
  const ack = response.ack;
  assertExactKeys(
    ack,
    ["operation", "status", "workspaceId", "sourceCoachId", "importRunId", "digest", "acceptedClientCount"],
    "ACK d'import"
  );
  const expected = request.snapshot;
  const matches = ack.operation === IMPORT_OPERATION
    && ack.status === "accepted"
    && strictIdentifier(ack.workspaceId, "workspaceId") === expected.workspaceId
    && strictIdentifier(ack.sourceCoachId, "sourceCoachId") === expected.sourceCoachId
    && strictImportRunId(ack.importRunId) === expected.importRunId
    && strictDigest(ack.digest) === request.digest
    && strictCount(ack.acceptedClientCount, "acceptedClientCount") === expected.clients.length;
  if (!matches) {
    throw new Error("L'ACK integrated-v1 ne correspond pas exactement a l'import envoye.");
  }
  return Object.freeze({
    workspaceId: expected.workspaceId,
    sourceCoachId: expected.sourceCoachId,
    importRunId: expected.importRunId,
    digest: request.digest,
    acceptedClientCount: expected.clients.length
  });
}

export function validateDryRunAck(response, request) {
  assertExactKeys(response, ["ok", "protocol", "ack"], "reponse de validation");
  if (response.ok !== true || response.protocol !== INTEGRATED_PROTOCOL) {
    throw new Error("Le backend n'a pas confirme integrated-v1.");
  }
  assertExactKeys(
    request,
    ["protocol", "operation", "extensionVersion", "snapshot", "digest", "dryRun"],
    "requete de validation attendue"
  );
  const ack = response.ack;
  assertExactKeys(
    ack,
    ["operation", "status", "dryRun", "workspaceId", "sourceCoachId", "importRunId", "digest", "acceptedClientCount"],
    "ACK de validation"
  );
  const expected = request.snapshot;
  const matches = request.operation === VALIDATE_OPERATION
    && request.dryRun === true
    && ack.operation === VALIDATE_OPERATION
    && ack.status === "validated"
    && ack.dryRun === true
    && strictIdentifier(ack.workspaceId, "workspaceId") === expected.workspaceId
    && strictIdentifier(ack.sourceCoachId, "sourceCoachId") === expected.sourceCoachId
    && strictImportRunId(ack.importRunId) === expected.importRunId
    && strictDigest(ack.digest) === request.digest
    && strictCount(ack.acceptedClientCount, "acceptedClientCount") === expected.clients.length;
  if (!matches) {
    throw new Error("L'ACK integrated-v1 ne correspond pas exactement au dry-run envoye.");
  }
  return Object.freeze({
    workspaceId: expected.workspaceId,
    sourceCoachId: expected.sourceCoachId,
    importRunId: expected.importRunId,
    digest: request.digest,
    acceptedClientCount: expected.clients.length,
    dryRun: true
  });
}

export function canonicalJson(value) {
  return JSON.stringify(canonicalValue(value));
}

export async function sha256Hex(value, subtle = globalThis.crypto?.subtle) {
  if (!subtle || typeof subtle.digest !== "function") {
    throw new Error("SHA-256 Web Crypto indisponible.");
  }
  const bytes = new TextEncoder().encode(String(value));
  const digest = await subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function qualifyClients(value, workspaceId, sourceCoachId) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 500) {
    throw new Error("Le roster CoachRx a qualifier n'est pas valide.");
  }
  const seen = new Set();
  return value.map((client) => {
    if (!isRecord(client)) throw new Error("Une fiche client CoachRx n'est pas valide.");
    const sourceClientId = canonicalSourceClientId(client);
    if (seen.has(sourceClientId)) throw new Error("Le roster contient un sourceClientId en double.");
    seen.add(sourceClientId);
    const result = { workspaceId, sourceCoachId, sourceClientId };
    for (const key of CLIENT_DATA_KEYS) {
      result[key] = strictJsonScalar(client[key], key);
    }
    return Object.freeze(result);
  });
}

function canonicalSourceClientId(client) {
  const explicit = String(client.sourceClientId ?? "").trim();
  if (explicit) {
    if (!RAW_CLIENT_ID_PATTERN.test(explicit)) {
      throw new Error("sourceClientId n'est pas un identifiant CoachRx brut valide.");
    }
    const legacyId = String(client.id ?? "").trim();
    if (legacyId && legacyId !== `id:${explicit}`) {
      throw new Error("sourceClientId ne correspond pas a l'identite CoachRx normalisee.");
    }
    return explicit;
  }
  if (client.identityKind !== "id" || !String(client.identitySource ?? "").trim()) {
    throw new Error("La fiche n'a pas une identite CoachRx stable.");
  }
  const qualified = String(client.id ?? "").trim();
  if (!qualified.startsWith("id:")) {
    throw new Error("L'identite CoachRx normalisee n'a pas le prefixe id: attendu.");
  }
  const raw = qualified.slice(3);
  if (!RAW_CLIENT_ID_PATTERN.test(raw)) {
    throw new Error("L'identite CoachRx normalisee n'est pas canonique.");
  }
  return raw;
}

function strictJsonScalar(value, label) {
  if (value === undefined || value === null) return "";
  if (typeof value === "string") {
    if (value.length > 4000 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)) {
      throw new Error(`Le champ ${label} n'est pas valide.`);
    }
    return value;
  }
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "boolean") return value;
  throw new Error(`Le champ ${label} n'est pas un scalaire JSON valide.`);
}

function canonicalValue(value) {
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (isRecord(value)) {
    const output = {};
    for (const key of Object.keys(value).sort()) {
      if (value[key] === undefined) throw new Error("Une valeur undefined ne peut pas etre canonisee.");
      output[key] = canonicalValue(value[key]);
    }
    return output;
  }
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  throw new Error("Valeur non JSON dans le calcul du digest.");
}

function assertExactKeys(value, expectedKeys, label) {
  if (!isRecord(value)) throw new Error(`La ${label} n'est pas un objet.`);
  const actual = Object.keys(value).sort();
  const expected = [...expectedKeys].sort();
  if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) {
    throw new Error(`La ${label} ne respecte pas le schema exact integrated-v1.`);
  }
}

function strictIdentifier(value, label) {
  const text = String(value ?? "").trim();
  if (!IDENTIFIER_PATTERN.test(text)) throw new Error(`${label} n'est pas un identifiant qualifie valide.`);
  return text;
}

function strictImportRunId(value) {
  const text = String(value ?? "").trim().toLowerCase();
  if (!UUID_PATTERN.test(text)) throw new Error("importRunId n'est pas un UUID valide.");
  return text;
}

function strictDigest(value) {
  const text = String(value ?? "").trim().toLowerCase();
  if (!DIGEST_PATTERN.test(text)) throw new Error("Le digest ACK n'est pas un SHA-256 valide.");
  return text;
}

function strictIsoInstant(value) {
  const text = String(value ?? "").trim();
  const time = Date.parse(text);
  if (!text || !Number.isFinite(time) || new Date(time).toISOString() !== text) {
    throw new Error("extractedAt doit etre un instant ISO canonique.");
  }
  return text;
}

function strictCount(value, label) {
  if (!Number.isInteger(value) || value < 0 || value > 100000) {
    throw new Error(`${label} n'est pas un compteur valide.`);
  }
  return value;
}

function strictText(value, label, maximumLength, allowEmpty) {
  if (typeof value !== "string") throw new Error(`${label} n'est pas du texte.`);
  const text = value.trim();
  if ((!allowEmpty && !text) || text.length > maximumLength || /[\u0000-\u001f\u007f]/.test(text)) {
    throw new Error(`${label} n'est pas valide.`);
  }
  return text;
}

function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const child of Object.values(value)) deepFreeze(child);
  return value;
}
