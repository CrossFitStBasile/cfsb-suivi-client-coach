# CFSB CoachRx Sync 0.7.0

Extension multicoach utilisant le protocole strict `integrated-v1`.

- La liste des coachs actifs est fournie et autorisee par le serveur.
- Le coach selectionne doit correspondre exactement a l'ID detecte dans l'URL
  et a la source CoachRx lue.
- `Valider sans ecrire (0 modification)` est obligatoire avant chaque import.
- L'import reutilise uniquement le roster, l'`importRunId` et le digest valides
  et gardes en memoire dans le popup.
- Le secret demeure dans `chrome.storage.local`; il n'est pas inclus dans le
  ZIP. Les anciennes cles de `chrome.storage.sync` sont retirees.
- Aucun outil de replay, scan avance ou diagnostic libre n'est distribue aux
  coachs.
- Les clients manuels du Dashboard et les questionnaires ne sont pas convertis
  ni modifies par la synchronisation CoachRx.

L'extraction CoachRx, les composants d'identite et de normalisation, le CSS et
les icones proviennent de la source scellee 0.6.11. Les permissions Chrome sont
inchangees.
