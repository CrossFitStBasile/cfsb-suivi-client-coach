import {
  createConfigRequest,
  createImportRequest,
  createImportRunId,
  createValidateRequest,
  validateConfigAck,
  validateDryRunAck,
  validateImportAck
} from "./protocol.js";

const webAppUrlInput = document.getElementById("webAppUrl");
const syncSecretInput = document.getElementById("syncSecret");
const coachSelect = document.getElementById("coachSelect");
const loadCoachesButton = document.getElementById("loadCoaches");
const saveSettingsButton = document.getElementById("saveSettings");
const validateRosterButton = document.getElementById("validateRoster");
const syncNowButton = document.getElementById("syncNow");
const openCoachRxButton = document.getElementById("openCoachRx");
const testCoachRxButton = document.getElementById("testCoachRx");
const logBox = document.getElementById("log");
const statusPill = document.getElementById("statusPill");

const MANAGED_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbypCU_Ba6W6SLUzLJXJnYcsKhF16oWJIAEt2G_lmwKd57IQNn_shs7-11I7Y-husyc/exec";
const MAX_SERVER_RESPONSE_CHARS = 65536;
const MAX_LOG_CHARS = 2400;
const MAX_ERROR_CHARS = 240;
let validatedImportContext = null;
let uiBusy = false;
const LOCAL_SETTING_KEYS = Object.freeze([
  "webAppUrl",
  "syncSecret",
  "workspaceId",
  "selectedSourceCoachId",
  "coachOptions",
  "endpointProtocol"
]);
const LEGACY_SYNC_KEYS = Object.freeze([
  "webAppUrl",
  "syncSecret",
  "selectedCoachId",
  "selectedCoachName",
  "coachOptions",
  "endpointRouteRelease",
  "dashboardSheet"
]);

init();

async function init() {
  const settings = await loadAndMigrateSettings();
  const endpointWasMigrated = settings.webAppUrl !== MANAGED_WEB_APP_URL
    || settings.endpointProtocol !== "integrated-v1";
  const nextSettings = {
    ...settings,
    webAppUrl: MANAGED_WEB_APP_URL,
    endpointProtocol: "integrated-v1"
  };
  await chrome.storage.local.set({
    webAppUrl: nextSettings.webAppUrl,
    endpointProtocol: nextSettings.endpointProtocol
  });
  webAppUrlInput.value = MANAGED_WEB_APP_URL;
  webAppUrlInput.readOnly = true;
  syncSecretInput.value = nextSettings.syncSecret || "";
  populateCoachSelect(sanitizeLocalCoachOptions(nextSettings.coachOptions), nextSettings.selectedSourceCoachId || "");
  loadCoachesButton.addEventListener("click", loadCoaches);
  saveSettingsButton.addEventListener("click", saveSettings);
  validateRosterButton.addEventListener("click", validateRosterNoWrite);
  syncNowButton.addEventListener("click", syncNow);
  openCoachRxButton.addEventListener("click", openSelectedCoachRx);
  testCoachRxButton.addEventListener("click", testCoachRx);
  coachSelect.addEventListener("change", invalidateValidatedRoster);
  updateActionState();
  if (endpointWasMigrated) {
    setStatus("A valider");
    writeLog("Configuration locale migree vers integrated-v1. Charge la liste des coachs avant la prochaine synchronisation.");
    return;
  }
  writeLog("Choisis un coach, ouvre sa page CoachRx > Clients, puis commence par Valider sans ecrire.");
}

async function loadAndMigrateSettings() {
  const [localSettings, legacySettings] = await Promise.all([
    chrome.storage.local.get(LOCAL_SETTING_KEYS),
    chrome.storage.sync.get(LEGACY_SYNC_KEYS)
  ]);
  const migration = {};
  if (!localSettings.syncSecret && typeof legacySettings.syncSecret === "string") {
    migration.syncSecret = legacySettings.syncSecret;
  }
  if (!localSettings.selectedSourceCoachId && legacySettings.selectedCoachId !== undefined) {
    migration.selectedSourceCoachId = String(legacySettings.selectedCoachId || "").trim();
  }
  if (Object.keys(migration).length) await chrome.storage.local.set(migration);
  await chrome.storage.sync.remove(LEGACY_SYNC_KEYS);
  return { ...localSettings, ...migration };
}

function sanitizeLocalCoachOptions(value) {
  if (!Array.isArray(value) || value.length > 100) return [];
  try {
    const response = {
      ok: true,
      protocol: "integrated-v1",
      ack: {
        operation: "get_coaches",
        status: "accepted",
        workspaceId: "local-validation",
        coaches: value
      }
    };
    return validateConfigAck(response).coaches;
  } catch {
    return [];
  }
}

async function saveSettings() {
  invalidateValidatedRoster();
  const selected = getSelectedCoach();
  await chrome.storage.local.set({
    webAppUrl: MANAGED_WEB_APP_URL,
    endpointProtocol: "integrated-v1",
    syncSecret: syncSecretInput.value,
    selectedSourceCoachId: selected.sourceCoachId
  });
  setStatus("Sauvegarde");
  writeLog("Parametres enregistres sur cet appareil.");
}

async function loadCoaches() {
  await runWithUi(async () => {
    invalidateValidatedRoster();
    const syncSecret = syncSecretInput.value;
    if (!syncSecret) throw new Error("Ajoute le secret de sync CoachRx.");
    setStatus("Config");
    const response = await fetch(MANAGED_WEB_APP_URL, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ secret: syncSecret, ...createConfigRequest() })
    });
    const body = await readBackendResponse(response);
    const accepted = validateConfigAck(body);
    if (!accepted.coaches.length) {
      throw new Error("Aucun coach actif n'est present dans la configuration integrated-v1.");
    }
    const previous = coachSelect.value;
    populateCoachSelect(accepted.coaches, previous);
    const selected = getSelectedCoach();
    await chrome.storage.local.set({
      webAppUrl: MANAGED_WEB_APP_URL,
      endpointProtocol: "integrated-v1",
      syncSecret,
      workspaceId: accepted.workspaceId,
      coachOptions: accepted.coaches,
      selectedSourceCoachId: selected.sourceCoachId
    });
    setStatus("Coachs OK");
    writeLog(`Configuration integrated-v1 chargee: ${accepted.coaches.length} coach(s) actif(s).`);
  });
}

async function testCoachRx() {
  await runWithUi(async () => {
    setStatus("Lecture");
    const data = await extractCoachRxDataFromActiveTab();
    setStatus("CoachRx OK");
    writeLog([
      "CoachRx repond.",
      `Coach ID: ${data.coachId || "-"}`,
      `Clients actifs valides: ${data.clients.length}/${data.expectedClientCount}`,
      `Clients archives ignores: ${data.archivedClientCount}`,
      `Fiches API totales: ${data.apiClientCount}`,
      `Identites stables: ${data.identityReport?.identifiedCount || 0}/${data.identityReport?.totalCount || data.clients.length}`,
      `Sources identite: ${identitySourceSummary(data.identityReport)}`
    ].join("\n"));
  });
}

async function openSelectedCoachRx() {
  const selected = getSelectedCoach();
  if (!selected.sourceCoachId) {
    writeLog("Choisis un coach avant d'ouvrir CoachRx.");
    return;
  }
  await saveSettings();
  await chrome.tabs.create({
    url: `https://dashboard.coachrx.app/team/${encodeURIComponent(selected.sourceCoachId)}/clients`
  });
  setStatus("CoachRx");
  writeLog(`Page CoachRx ouverte pour ${selected.label || selected.sourceCoachId}.`);
}

async function validateRosterNoWrite() {
  invalidateValidatedRoster();
  await runWithUi(async () => {
    const prepared = await prepareRosterRequest("validate");
    setStatus("Validation 0 ecriture");
    writeLog(`Validation sans ecriture ${prepared.request.snapshot.importRunId}: ${prepared.request.snapshot.clients.length} client(s) qualifies.`);
    const body = await postProtocolRequest(prepared.syncSecret, prepared.request);
    const accepted = validateDryRunAck(body, prepared.request);
    const importRequest = await createImportRequest(prepared.input);
    if (importRequest.digest !== accepted.digest
      || importRequest.snapshot.importRunId !== accepted.importRunId) {
      throw new Error("Le roster valide ne peut pas etre reutilise exactement pour l'import.");
    }
    validatedImportContext = Object.freeze({
      request: importRequest,
      syncSecret: prepared.syncSecret,
      selected: prepared.selected
    });
    updateActionState();
    setStatus("Valide: 0 ecriture");
    writeLog([
      "VALIDATION SANS ECRITURE REUSSIE.",
      "Aucune donnee Dashboard n'a ete importee ou modifiee par cette operation.",
      `Coach: ${accepted.sourceCoachId}`,
      `Clients valides: ${accepted.acceptedClientCount}`,
      `Validation: ${accepted.importRunId}`,
      `Digest: ${accepted.digest}`,
      "L'import est maintenant deverrouille pour ce roster garde en memoire."
    ].join("\n"));
  });
}

async function syncNow() {
  await runWithUi(async () => {
    const { request, selected, syncSecret } = takeValidatedImportContext();

    setStatus("Envoi");
    writeLog(`Import ${request.snapshot.importRunId}: ${request.snapshot.clients.length} client(s) qualifies.`);
    const body = await postProtocolRequest(syncSecret, request);
    const accepted = validateImportAck(body, request);
    setStatus("Termine");
    writeLog([
      "Sync integrated-v1 terminee.",
      `Coach: ${selected.label || accepted.sourceCoachId}`,
      `Clients acceptes: ${accepted.acceptedClientCount}`,
      `Import: ${accepted.importRunId}`,
      `Digest: ${accepted.digest}`
    ].join("\n"));
  });
}

async function prepareRosterRequest(mode) {
  const settings = await chrome.storage.local.get(LOCAL_SETTING_KEYS);
  const syncSecret = settings.syncSecret || syncSecretInput.value;
  const selected = getSelectedCoach();
  if (!syncSecret) throw new Error("Ajoute le secret de sync CoachRx.");
  if (!settings.workspaceId) throw new Error("Charge la configuration integrated-v1 avant l'operation.");
  if (!selected.sourceCoachId) throw new Error("Choisis le coach dans la liste deroulante.");
  setStatus("Lecture");
  writeLog("Lecture et qualification des clients CoachRx...");
  const data = await extractCoachRxDataFromActiveTab();
  const identityReport = data.identityReport || {};
  if (!identityReport.totalCount || identityReport.missingCount > 0
    || identityReport.identifiedCount !== identityReport.totalCount) {
    throw new Error("Chaque client doit posseder une identite CoachRx stable avant l'operation.");
  }
  if (String(data.coachId) !== selected.sourceCoachId) {
    throw new Error("Le coach choisi ne correspond pas au CoachRx ID detecte dans l'URL.");
  }
  if (!sourcePathMatchesCoach(data.sourcePath, data.sourceMode, selected.sourceCoachId)) {
    throw new Error("La source CoachRx ne correspond pas au coach selectionne.");
  }

  const input = {
    workspaceId: settings.workspaceId,
    sourceCoachId: selected.sourceCoachId,
    importRunId: createImportRunId(),
    extractedAt: new Date().toISOString(),
    expectedClientCount: data.expectedClientCount,
    archivedClientCount: data.archivedClientCount,
    apiClientCount: data.apiClientCount,
    countSource: data.countSource,
    clients: data.clients
  };
  if (mode !== "validate") {
    throw new Error("La preparation directe d'un import est interdite avant le dry-run.");
  }
  const request = await createValidateRequest(input);
  return Object.freeze({ settings, syncSecret, selected, data, input, request });
}

function takeValidatedImportContext() {
  if (!validatedImportContext) {
    throw new Error("Execute d'abord Valider sans ecrire pour ce roster.");
  }
  const context = validatedImportContext;
  validatedImportContext = null;
  updateActionState();
  return context;
}

function invalidateValidatedRoster() {
  validatedImportContext = null;
  updateActionState();
}

async function postProtocolRequest(syncSecret, request) {
  return postSerializedProtocolRequest(JSON.stringify({ secret: syncSecret, ...request }));
}

async function postSerializedProtocolRequest(serializedPayload) {
  const response = await fetch(MANAGED_WEB_APP_URL, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: serializedPayload
  });
  return readBackendResponse(response);
}

async function readBackendResponse(response) {
  const text = await response.text();
  if (text.length > MAX_SERVER_RESPONSE_CHARS) {
    throw new Error("Reponse backend trop volumineuse; operation bloquee.");
  }
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`Reponse backend invalide (HTTP ${safeHttpStatus(response.status)}).`);
  }
  if (!response.ok) throw new Error(`Backend refuse (HTTP ${safeHttpStatus(response.status)}).`);
  return body;
}

function safeHttpStatus(value) {
  const status = Number(value);
  return Number.isInteger(status) && status >= 100 && status <= 599 ? status : 0;
}

function sourcePathMatchesCoach(sourcePath, sourceMode, coachId) {
  const path = String(sourcePath || "");
  const escapedCoachId = String(coachId || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (!escapedCoachId) return false;
  if (sourceMode === "coachrx-page-api") {
    return new RegExp(`/api/v1/coaches/${escapedCoachId}/clients(?:\\.json)?(?:[?#]|$)`, "i").test(path);
  }
  if (sourceMode === "coachrx-visible-page") {
    return new RegExp(`/team/${escapedCoachId}/clients(?:[/?#]|$)`, "i").test(path);
  }
  return false;
}

async function extractCoachRxDataFromActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id || !tab.url || !tab.url.startsWith("https://dashboard.coachrx.app/")) {
    throw new Error("Ouvre un onglet https://dashboard.coachrx.app/ connecte avant de synchroniser.");
  }
  const coachId = coachIdFromCoachRxClientsUrl(tab.url);
  if (!coachId) {
    throw new Error("Ouvre la page Clients du coach vise: https://dashboard.coachrx.app/team/{coachId}/clients.");
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      files: ["coachrx-identity.js", "coachrx-normalize.js"]
    });
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: fetchCoachRxRawDataInMainWorld,
      args: [coachId]
    });
    if (!result || !result.ok) {
      throw new Error(result?.error || "Lecture API CoachRx impossible dans la session connectee.");
    }
    return result;
  } finally {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: cleanupCoachRxMainWorldHelpers
      });
    } catch {
      // The extraction result remains fail-closed even if the page disappeared
      // before the best-effort cleanup could execute.
    }
  }
}

function cleanupCoachRxMainWorldHelpers() {
  delete globalThis.CFSBCoachRxIdentity;
  delete globalThis.CFSBCoachRxNormalize;
}

function coachIdFromCoachRxClientsUrl(value) {
  const match = String(value || "").match(/^https:\/\/dashboard\.coachrx\.app\/team\/(\d+)\/clients(?:[/?#]|$)/i);
  return match ? match[1] : "";
}

async function fetchCoachRxRawDataInMainWorld(expectedCoachId) {
  try {
    const coachId = String(expectedCoachId || "").trim();
    const urlMatch = window.location.href.match(/^https:\/\/dashboard\.coachrx\.app\/team\/(\d+)\/clients(?:[/?#]|$)/i);
    if (!coachId || !urlMatch || urlMatch[1] !== coachId) {
      throw new Error("La page CoachRx ouverte ne correspond pas au coach selectionne.");
    }

    const identityApi = globalThis.CFSBCoachRxIdentity;
    const normalizeApi = globalThis.CFSBCoachRxNormalize;
    if (!identityApi || !normalizeApi || typeof normalizeApi.normalizeRoster !== "function") {
      throw new Error("Modules de normalisation CoachRx indisponibles. Recharge l'extension puis reessaie.");
    }

    const token = String(window.localStorage.getItem("token") || "").trim();
    if (!token) {
      throw new Error("Session API CoachRx introuvable. Deconnecte-toi puis reconnecte-toi a CoachRx.");
    }

    const readJson = async (path) => {
      const response = await fetch(path, {
        credentials: "include",
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`
        }
      });
      const text = await response.text();
      let json;
      try {
        json = text ? JSON.parse(text) : {};
      } catch {
        throw new Error(`CoachRx a retourne du non JSON (${response.status}).`);
      }
      if (!response.ok) throw new Error(`CoachRx a refuse la lecture API (HTTP ${safeCoachRxStatus(response.status)}).`);
      return json;
    };
    const clientsFrom = (data) => Array.isArray(data?.clients)
      ? data.clients
      : Array.isArray(data)
        ? data
        : [];
    const sourcePath = `/api/v1/coaches/${coachId}/clients.json`;
    const data = await readJson(sourcePath);
    const clients = clientsFrom(data);
    if (!clients.length) throw new Error("Aucun client retourne par l API CoachRx.");

    const pageCounts = readVisiblePortfolioCounts();
    if (pageCounts.active !== null && pageCounts.totalMetric !== null
      && pageCounts.active !== pageCounts.totalMetric) {
      throw new Error(
        `Les compteurs actifs CoachRx ne concordent pas: onglet ${pageCounts.active}, carte Total Clients ${pageCounts.totalMetric}.`
      );
    }

    const expectedClientCount = pageCounts.active !== null
      ? pageCounts.active
      : pageCounts.totalMetric;
    const countSource = pageCounts.active !== null ? "onglet Active" : "carte Total Clients";
    if (expectedClientCount === null) {
      throw new Error("Compteur de clients actifs introuvable dans CoachRx; synchronisation bloquee par securite.");
    }

    const classifiedClients = clients.map((client) => ({ client, state: coachRxClientState(client) }));
    const unknownStates = classifiedClients
      .filter(({ state }) => state !== "active" && state !== "archived")
      .map(({ state }) => state || "(vide)");
    if (unknownStates.length) {
      const stateSummary = Array.from(new Set(unknownStates)).slice(0, 5).join(", ");
      throw new Error(
        `Etat CoachRx non reconnu pour ${unknownStates.length} fiche(s): ${stateSummary}. Synchronisation bloquee par securite.`
      );
    }
    const activeClients = classifiedClients
      .filter(({ state }) => state === "active")
      .map(({ client }) => client);
    const archivedClients = classifiedClients
      .filter(({ state }) => state === "archived")
      .map(({ client }) => client);
    if (activeClients.length !== expectedClientCount) {
      throw new Error(
        `Extraction active incomplete: ${activeClients.length} client(s) actif(s) lu(s) sur ${expectedClientCount} affiche(s) par CoachRx.`
      );
    }
    if (pageCounts.archived !== null && archivedClients.length !== pageCounts.archived) {
      throw new Error(
        `Extraction archivee incomplete: ${archivedClients.length} fiche(s) archivee(s) lue(s) sur ${pageCounts.archived} affichee(s) par CoachRx.`
      );
    }
    if (pageCounts.archived !== null
      && clients.length !== expectedClientCount + pageCounts.archived) {
      throw new Error(
        `Extraction globale incomplete: ${clients.length} fiche(s) API sur ${expectedClientCount + pageCounts.archived} attendue(s).`
      );
    }

    const normalized = normalizeApi.normalizeRoster(activeClients, coachId, sourcePath, identityApi);
    if (!normalized.clients.length) throw new Error("Aucun client retourne par CoachRx.");
    if (normalized.clients.length !== expectedClientCount) {
      throw new Error(
        `Normalisation incomplete: ${normalized.clients.length} client(s) exploitable(s) sur ${expectedClientCount} dans CoachRx.`
      );
    }

    return {
      ok: true,
      coachId,
      sourceMode: "coachrx-page-api",
      sourcePath,
      pageCount: 1,
      expectedClientCount,
      archivedClientCount: archivedClients.length,
      apiClientCount: clients.length,
      countSource,
      clients: normalized.clients,
      identityReport: normalized.identityReport
    };
  } catch (error) {
    return {
      ok: false,
      error: String(error && error.message ? error.message : error)
    };
  }

  function coachRxClientState(client) {
    return String(client?.state || "").trim().toLowerCase();
  }

  function safeCoachRxStatus(value) {
    const status = Number(value);
    return Number.isInteger(status) && status >= 100 && status <= 599 ? status : 0;
  }

  function readVisiblePortfolioCounts() {
    const bodyText = String(document.body?.innerText || "").replace(/\u00a0/g, " ");
    const result = { active: null, archived: null, totalMetric: null };
    const elements = Array.from(document.querySelectorAll("body *"));
    for (const element of elements) {
      const text = String(element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
      let match = text.match(/^active\s+(\d+)$/i);
      if (match && result.active === null) result.active = Number(match[1]);
      match = text.match(/^archived\s+(\d+)$/i);
      if (match && result.archived === null) result.archived = Number(match[1]);
      match = text.match(/^(\d+)\s+total\s+clients?$/i);
      if (match && result.totalMetric === null) result.totalMetric = Number(match[1]);
      if (result.active !== null && result.archived !== null && result.totalMetric !== null) {
        break;
      }
    }

    if (result.active === null) {
      const match = bodyText.match(/(?:^|\n)\s*active\s+(\d+)\s*(?:\n|$)/i);
      if (match) result.active = Number(match[1]);
    }
    if (result.archived === null) {
      const match = bodyText.match(/(?:^|\n)\s*archived\s+(\d+)\s*(?:\n|$)/i);
      if (match) result.archived = Number(match[1]);
    }
    if (result.totalMetric === null) {
      const match = bodyText.match(/(?:^|\n)\s*(\d+)\s*(?:\n|\s)+total\s+clients?\s*(?:\n|$)/i);
      if (match) result.totalMetric = Number(match[1]);
    }
    return result;
  }
}

async function runWithUi(task) {
  setBusy(true);
  try {
    await task();
  } catch (error) {
    setStatus("Erreur");
    writeLog(`Erreur: ${boundedErrorMessage(error)}`);
  } finally {
    setBusy(false);
  }
}

function setBusy(isBusy) {
  uiBusy = isBusy;
  validateRosterButton.disabled = isBusy;
  testCoachRxButton.disabled = isBusy;
  loadCoachesButton.disabled = isBusy;
  saveSettingsButton.disabled = isBusy;
  updateActionState();
}

function updateActionState() {
  syncNowButton.disabled = uiBusy || !validatedImportContext;
}

function setStatus(text) {
  statusPill.textContent = text;
}

function writeLog(text) {
  logBox.textContent = boundedText(text, MAX_LOG_CHARS);
}

function boundedErrorMessage(error) {
  const value = error && error.message ? error.message : error;
  return boundedText(value, MAX_ERROR_CHARS) || "Erreur inattendue.";
}

function boundedText(value, maximumLength) {
  const text = String(value === undefined || value === null ? "" : value)
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "")
    .trim();
  return text.length <= maximumLength
    ? text
    : `${text.slice(0, Math.max(0, maximumLength - 3))}...`;
}

function identitySourceSummary(report) {
  const entries = Object.entries(report?.bySource || {})
    .sort(([left], [right]) => left.localeCompare(right));
  return entries.length
    ? entries.map(([source, count]) => `${source}: ${count}`).join(" | ")
    : "aucune identite stable detectee";
}

function populateCoachSelect(coaches, selectedSourceCoachId) {
  coachSelect.innerHTML = "";
  if (!coaches.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Charge la liste des coachs";
    coachSelect.append(option);
    return;
  }
  for (const coach of coaches) {
    const option = document.createElement("option");
    option.value = coach.sourceCoachId;
    option.textContent = `${coach.label} (${coach.sourceCoachId})`;
    option.dataset.label = coach.label;
    coachSelect.append(option);
  }
  if (selectedSourceCoachId
    && coaches.some((coach) => coach.sourceCoachId === String(selectedSourceCoachId))) {
    coachSelect.value = String(selectedSourceCoachId);
  }
}

function getSelectedCoach() {
  const option = coachSelect.selectedOptions[0];
  return {
    sourceCoachId: String(coachSelect.value || ""),
    label: String(option?.dataset.label || "")
  };
}
